package com.example.onlinequizz.Model;

public class User {
    private String userName;
    private String password;
    private String emale;

    public User() {
    }

    public User(String userName, String password, String emale) {
        this.userName = userName;
        this.password = password;
        this.emale = emale;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmale() {
        return emale;
    }

    public void setEmale(String emale) {
        this.emale = emale;
    }
}
